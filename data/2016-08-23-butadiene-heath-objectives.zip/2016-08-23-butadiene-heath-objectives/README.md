# Butadiene: Comparison with health objective for 2003

The data set for this challenge consists of a single CSV file from the 
[UK Open Government Data portal](https://data.gov.uk/). The data set contains
annual means of measurements of 1,3-butadiene at a number of automatic sites
and provides comparison with health objective for 2003.
This challenge is an example of a "messy real-world CSV file". The file contains
table with data, but also various additional meta-data about the data set. 
